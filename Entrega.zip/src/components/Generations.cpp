#include "Generations.h"

Generations::Generations(int n) 
	:currentGenerations(n)
{
}

Generations::~Generations()
{
}
